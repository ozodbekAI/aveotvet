from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db, get_current_user
from app.repos.shop_repo import ShopRepo
from app.schemas.settings import SettingsOut, SettingsUpdate

router = APIRouter()


def validate_config(config: dict) -> dict:
    """Validate and normalize config structure."""
    if not isinstance(config, dict):
        raise HTTPException(status_code=422, detail="config must be an object")
    
    result = {}
    
    # Advanced settings
    if "advanced" in config:
        adv = config["advanced"]
        if not isinstance(adv, dict):
            raise HTTPException(status_code=422, detail="config.advanced must be an object")
        
        advanced = {}
        
        # Address format
        if "address_format" in adv:
            af = adv["address_format"]
            if af not in ("vy_caps", "vy_lower", "ty"):
                raise HTTPException(status_code=422, detail="address_format must be one of: vy_caps, vy_lower, ty")
            advanced["address_format"] = af
        
        # Boolean flags
        for key in ("use_buyer_name", "mention_product_name", "emoji_enabled", "photo_reaction_enabled"):
            if key in adv:
                if not isinstance(adv[key], bool):
                    raise HTTPException(status_code=422, detail=f"{key} must be boolean")
                advanced[key] = adv[key]
        
        # Answer length
        if "answer_length" in adv:
            al = adv["answer_length"]
            if al not in ("short", "default", "long"):
                raise HTTPException(status_code=422, detail="answer_length must be one of: short, default, long")
            advanced["answer_length"] = al
        
        # Delivery method
        if "delivery_method" in adv:
            dm = adv["delivery_method"]
            if dm is not None and not isinstance(dm, str):
                raise HTTPException(status_code=422, detail="delivery_method must be string or null")
            advanced["delivery_method"] = dm.strip() if isinstance(dm, str) and dm.strip() else None
        
        # Tone of voice
        if "tone_of_voice" in adv:
            tov = adv["tone_of_voice"]
            if not isinstance(tov, dict):
                raise HTTPException(status_code=422, detail="tone_of_voice must be an object")
            
            tone_of_voice = {}
            for key in ("positive", "neutral", "negative", "question"):
                if key in tov:
                    if not isinstance(tov[key], str):
                        raise HTTPException(status_code=422, detail=f"tone_of_voice.{key} must be string")
                    tone_of_voice[key] = tov[key].strip()
            
            if tone_of_voice:
                advanced["tone_of_voice"] = tone_of_voice
        
        # Stop words
        if "stop_words" in adv:
            sw = adv["stop_words"]
            if not isinstance(sw, list):
                raise HTTPException(status_code=422, detail="stop_words must be an array")
            stop_words = []
            for word in sw:
                if isinstance(word, str) and word.strip():
                    stop_words.append(word.strip()[:100])
            advanced["stop_words"] = stop_words
        
        if advanced:
            result["advanced"] = advanced
    
    # Chat settings
    if "chat" in config:
        chat = config["chat"]
        if not isinstance(chat, dict):
            raise HTTPException(status_code=422, detail="config.chat must be an object")
        
        chat_settings = {}
        for key in ("confirm_send", "confirm_ai_insert"):
            if key in chat:
                if not isinstance(chat[key], bool):
                    raise HTTPException(status_code=422, detail=f"chat.{key} must be boolean")
                chat_settings[key] = chat[key]
        
        if chat_settings:
            result["chat"] = chat_settings
    
    # Recommendations
    if "recommendations" in config:
        rec = config["recommendations"]
        if not isinstance(rec, dict):
            raise HTTPException(status_code=422, detail="config.recommendations must be an object")
        
        recommendations = {}
        if "enabled" in rec:
            if not isinstance(rec["enabled"], bool):
                raise HTTPException(status_code=422, detail="recommendations.enabled must be boolean")
            recommendations["enabled"] = rec["enabled"]
        
        if recommendations:
            result["recommendations"] = recommendations
    
    return result


@router.get("/{shop_id}", response_model=SettingsOut)
async def get_settings(shop_id: int, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    shop = await ShopRepo(db).get(user.id, shop_id)
    if not shop:
        raise HTTPException(status_code=404, detail="Shop not found")
    s = await ShopRepo(db).get_settings(shop_id)
    if not s:
        raise HTTPException(status_code=404, detail="Settings not found")
    return s


@router.put("/{shop_id}", response_model=SettingsOut)
async def update_settings(shop_id: int, payload: SettingsUpdate, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    shop = await ShopRepo(db).get(user.id, shop_id)
    if not shop:
        raise HTTPException(status_code=404, detail="Shop not found")

    s = await ShopRepo(db).get_settings(shop_id)
    if not s:
        raise HTTPException(status_code=404, detail="Settings not found")

    data = payload.model_dump(exclude_unset=True)

    # Validate and process signatures
    if "signatures" in data:
        sigs = data.get("signatures")
        if sigs is None:
            data["signatures"] = []
        elif not isinstance(sigs, list):
            raise HTTPException(status_code=422, detail="signatures must be a list")
        else:
            cleaned: list = []
            for item in sigs:
                if isinstance(item, str):
                    t = item.strip()
                    if t:
                        cleaned.append(t[:300])
                    continue
                if isinstance(item, dict):
                    text = item.get("text")
                    if not isinstance(text, str) or not text.strip():
                        raise HTTPException(status_code=422, detail="signature item must have non-empty 'text'")
                    cleaned.append(
                        {
                            "text": text.strip()[:300],
                            "type": str(item.get("type", "all"))[:32],
                            "brand": str(item.get("brand", "all"))[:128],
                            "created_at": item.get("created_at"),
                        }
                    )
                    continue
                raise HTTPException(status_code=422, detail="signatures items must be strings or objects")
            data["signatures"] = cleaned

    # Validate and process config
    if "config" in data:
        config = data["config"]
        if config is None:
            data["config"] = {}
        else:
            # Merge with existing config
            existing_config = s.config or {}
            validated_config = validate_config(config)
            
            # Deep merge: update existing keys, keep others
            for key, value in validated_config.items():
                if key in existing_config and isinstance(existing_config[key], dict) and isinstance(value, dict):
                    existing_config[key].update(value)
                else:
                    existing_config[key] = value
            
            data["config"] = existing_config

    for k, v in data.items():
        setattr(s, k, v)

    await db.commit()
    return s