from __future__ import annotations

from pydantic import BaseModel, Field, field_validator
from typing import Literal


class ToneOfVoiceConfig(BaseModel):
    """Tone of voice settings per feedback type."""
    positive: str | None = Field(default=None, description="Tone for positive reviews")
    neutral: str | None = Field(default=None, description="Tone for neutral reviews")
    negative: str | None = Field(default=None, description="Tone for negative reviews")
    question: str | None = Field(default=None, description="Tone for questions")


class AdvancedConfig(BaseModel):
    """Advanced prompt configuration."""
    address_format: Literal["vy_caps", "vy_lower", "ty"] | None = Field(
        default=None,
        description="How to address customers: vy_caps (Вы), vy_lower (вы), ty (ты)"
    )
    use_buyer_name: bool | None = Field(default=None, description="Include buyer's name in response")
    mention_product_name: bool | None = Field(default=None, description="Mention product name in response")
    answer_length: Literal["short", "default", "long"] | None = Field(
        default=None,
        description="Preferred response length"
    )
    emoji_enabled: bool | None = Field(default=None, description="Allow emojis in responses")
    photo_reaction_enabled: bool | None = Field(
        default=None,
        description="Thank customers for photos/videos"
    )
    delivery_method: str | None = Field(default=None, description="Delivery method to mention")
    tone_of_voice: ToneOfVoiceConfig | None = Field(default=None, description="Tone settings per type")
    stop_words: list[str] | None = Field(default=None, description="Words/phrases to avoid")

    @field_validator("stop_words")
    @classmethod
    def validate_stop_words(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return None
        return [word.strip()[:100] for word in v if isinstance(word, str) and word.strip()]


class ChatConfig(BaseModel):
    """Chat-related settings."""
    confirm_send: bool | None = Field(default=None, description="Show confirmation before sending")
    confirm_ai_insert: bool | None = Field(
        default=None,
        description="Show confirmation before inserting AI response"
    )


class RecommendationsConfig(BaseModel):
    """Product recommendations settings."""
    enabled: bool | None = Field(default=None, description="Enable product recommendations")


class ConfigUpdate(BaseModel):
    """Full config structure for updates."""
    advanced: AdvancedConfig | None = None
    chat: ChatConfig | None = None
    recommendations: RecommendationsConfig | None = None


class ConfigResponse(BaseModel):
    """Full config structure for responses."""
    advanced: AdvancedConfig = Field(default_factory=AdvancedConfig)
    chat: ChatConfig = Field(default_factory=ChatConfig)
    recommendations: RecommendationsConfig = Field(default_factory=RecommendationsConfig)