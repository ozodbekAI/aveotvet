from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel


class DraftOut(BaseModel):
    id: int
    feedback_id: int
    status: str
    text: str
    openai_model: str | None = None
    openai_response_id: str | None = None
    created_at: datetime

    class Config:
        from_attributes = True

from datetime import datetime
from pydantic import BaseModel, Field


class FeedbackShortInfo(BaseModel):
    """Short feedback info for draft list."""
    id: int
    wb_id: str
    user_name: str | None
    text: str | None
    product_valuation: int | None
    created_at: datetime
    
    class Config:
        from_attributes = True


class DraftListItem(BaseModel):
    """Draft list item with basic info."""
    id: int
    feedback_id: int
    status: str
    text: str
    created_at: datetime
    published_at: datetime | None
    
    feedback: FeedbackShortInfo
    
    class Config:
        from_attributes = True


class DraftDetail(BaseModel):
    """Full draft details."""
    id: int
    feedback_id: int
    status: str
    text: str
    openai_model: str | None
    openai_response_id: str | None
    prompt_version: str
    error: str | None
    created_at: datetime
    updated_at: datetime
    published_at: datetime | None
    
    # Include full feedback info
    feedback: FeedbackShortInfo
    
    class Config:
        from_attributes = True


class DraftUpdateRequest(BaseModel):
    """Request to update draft."""
    text: str | None = Field(default=None, description="Updated draft text")
    status: str | None = Field(
        default=None, 
        description="Draft status: drafted|published|rejected"
    )


class DraftStats(BaseModel):
    """Draft statistics."""
    total: int = Field(description="Total drafts")
    drafted: int = Field(description="Pending drafts waiting for review")
    published: int = Field(description="Published drafts")
    rejected: int = Field(description="Rejected drafts")