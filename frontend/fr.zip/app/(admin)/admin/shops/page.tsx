"use client"

import AdminShopsModule from "@/components/modules/admin-shops-module"

export default function AdminShopsPage() {
  return <AdminShopsModule />
}
