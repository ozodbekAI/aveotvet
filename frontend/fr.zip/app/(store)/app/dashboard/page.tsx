import DashboardModule from "@/components/modules/dashboard-module"

export default function DashboardPage() {
  return <DashboardModule />
}
