export const AUTH_COOKIE_NAME = "wb_otveto_access_token"
