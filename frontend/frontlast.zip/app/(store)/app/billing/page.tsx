"use client"

import BillingModule from "@/components/modules/billing-module"

export default function BillingPage() {
  return <BillingModule />
}
