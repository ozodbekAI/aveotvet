"use client"

import TeamModule from "@/components/modules/team-module"

export default function TeamPage() {
  return <TeamModule />
}
